package com.java.fsd.methodoverloading;

public class Main {
	public static void main(String[] args) {
		System.out.println(Child.add(11, 11));
		System.out.println(Child.add(11, 11, 11));
	}
}
