package com.java.fsd.datatypes;

public class TestDataTypes {
	public static void main(String[] args) {
		int max_value = 2147483647;
		System.out.println("Maximum value of int is  " + max_value++);
		System.out.println("Maximum value of int is  " + max_value);
		
	}
}
