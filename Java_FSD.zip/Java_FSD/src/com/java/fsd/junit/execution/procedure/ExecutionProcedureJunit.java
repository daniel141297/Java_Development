package com.java.fsd.junit.execution.procedure;

import org.junit.After;
import org.junit.AfterClass;

import org.junit.Before;
import org.junit.BeforeClass;

import org.junit.Test;

public class ExecutionProcedureJunit {

	// execute only once, in the starting
	@BeforeClass
	public static void beforeClass() {
		System.out.println("in before class");
	}

	// execute only once, in the end
	@AfterClass
	public static void afterClass() {
		System.out.println("in after class");
	}

	// execute for each test, before executing test
	@Before
	public void before() {
		System.out.println("in before");
	}

	// execute for each test, after executing test
	@After
	public void after() {
		System.out.println("in after");
	}

	// test case 1
	@Test
	public void testCase1() {
		System.out.println("in test case 1");
	}

	// test case 2
	@Test
	public void testCase2() {
		System.out.println("in test case 2");
	}

	/*
	 * First of all, the beforeClass() method executes only once. 
	 * The afterClass() method executes only once.
	 * The before() method executes for each test case,but before executing the test case.
	 * The after() method executes for each test case, but after the execution of test case. 
	 * In between before() and after(), each test case executes.
	 * 
	*/
}