package com.java.fsd.encapsulation;

public class EncapsulationTest {
	public static void main(String[] args) {
//creating instance of Account class    
		Customer acc = new Customer();
//setting values through setter methods    
		acc.setAcc_no(7560504000L);
		acc.setName("Mark Dennis");
		acc.setEmail("md123@gmail.com");
		acc.setAmount(500000f);
		acc.acc_no= 11003355;
//getting values through getter methods    
		System.out.println(acc.getAcc_no() + " " + acc.getName() + " " + acc.getEmail() + " " + acc.getAmount());
	}
}
