package com.java.fsd.collections;

import java.util.*;

public class DequeueExample {
	public static void main(String[] args) {
//Creating Deque and adding elements  
		Deque<String> deque = new ArrayDeque<String>();
		deque.add("Gautam");
		deque.add("Karan");
		deque.add("Ajay");
//Traversing elements  
		for (String str : deque) {
			System.out.println(str);
		}
		deque.removeFirst();
		System.out.println("-----------------");
		System.out.println("After remove");
		System.out.println("-------------");
		for (String remstr : deque) {
			System.out.println(remstr);
		}
	}
}