package com.java.fsd.collections;

import java.util.*;

public class TreeSetExample {
	public static void main(String args[]) {
//Creating and adding elements  
		TreeSet<String> set = new TreeSet<String>();
		set.add("Ravi");
		set.add("Vijay");
		set.add("Ravi");
		set.add("Ajay");

		Iterator<String> itr = set.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
		/*
		 * set.removeAll(set); Iterator<String> itr2 = set.iterator(); while
		 * (itr2.hasNext()) { System.out.println("After Removal");
		 * System.out.println(itr2.next()); System.out.println("------------"); }
		 */
		
	
	}
}