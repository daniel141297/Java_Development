package com.java.fsd.arrays;

import java.io.IOException;
import java.util.Scanner;

public class StudentHwArrays {
	public static void main(String[] args) throws IOException {

		int[] Maths = { 100, 95, 88, 78, 90 };
		int[] Physics = { 56, 75, 86, 63, 70 };
		int[] Chemistry = { 68, 65, 66, 69, 61 };
		int[] History = { 77, 79, 78, 70, 71 };
		int[] Language = { 89, 70, 71, 76, 69 };
		String studName[] = { "Bryan", "Marshal", "Denise", "Rajan", "Mamtha" };

		
		int total = 0;

		for (int i = 0; i < studName.length; i++) {
			for (int j = 0; j < studName.length; j++) {
				
				System.out.println("Student:  " + studName[j]);
				total = Maths[i] + Physics[i] + Chemistry[i] + History[i] + Language[i];
				
				System.out.println("Total marks obtained " + total);
				i++;
							
			}
						
		}
		
	}
}
