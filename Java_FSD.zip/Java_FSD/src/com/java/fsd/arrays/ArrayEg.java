package com.java.fsd.arrays;


import java.util.Scanner; 
public class ArrayEg
{ 
     public static void main(String[] args) 
     { 
            int[] [] a = new int[2] [5]; 
            int i, j; 
            Scanner input=new Scanner(System.in); 
            System.out.print("Enter the Elements of :"); 
            for(i=0;i<2; i++) 
                { 
                   for(j=0; j<5;j++) 
                   a[i] [j]=input.nextInt(); 
                } 
            System.out.println("Elements infrom are :"); 
            for(i=0;i<2;i++) 
                {   
                   for(j=0; j<5; j++) 
                       System.out.print(a[i][j]+" "); 
                       System.out.println(); 
                } 
       } 
} 