package com.java.fsd.arrays;


class StudentDemo

{

    public static void main(String args[])

    {

        Student s[]=new Student[5];

        for(int i=0;i<5;i++)

              s[i]=new Student();

     }

}