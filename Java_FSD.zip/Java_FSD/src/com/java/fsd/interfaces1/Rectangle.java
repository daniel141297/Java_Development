package com.java.fsd.interfaces1;

class Rectangle implements Drawable{  
public void draw(){System.out.println("drawing rectangle");}  
}  