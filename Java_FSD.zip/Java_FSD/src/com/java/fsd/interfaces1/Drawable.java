package com.java.fsd.interfaces1;

interface Drawable{  
void draw();  
static int cube(int x){return x*x*x;}  
}  