package com.java.fsd;

public class SimpleAdd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a,b;
		a=50;
		b=20;
		
		System.out.println("a"+a+  "   b"+b);
		a=a+b;
		b=a-b;
		a=a-b;
		System.out.println("a= "+a+  "  b= "+b);

		
		
	}

}
