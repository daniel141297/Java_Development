package com.java.fsd.linkedlist;

import java.util.LinkedList;

public class AppendElementEnd {
	public static void main(String[] args) {
		LinkedList<String> l_list = new LinkedList<String>();
		l_list.add("Red");
		l_list.add("Green");
		l_list.add("Black");
		l_list.add("White");
		l_list.add("Pink");
		l_list.add("Yellow");

		System.out.println("The linked list: " + l_list);
	}
}