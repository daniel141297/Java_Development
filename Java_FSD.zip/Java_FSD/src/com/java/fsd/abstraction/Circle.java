package com.java.fsd.abstraction;

class Circle extends Shape 
{  
//implementing functionality of the abstract method  
public void draw()   
{  
System.out.println("Circle!");  
}  
} 
  
