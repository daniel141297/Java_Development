package com.java.fsd.abstraction;

abstract class Square   
{  
//abstract method  
//note that we have not implemented the functionality of the method  
public abstract void draw();  
}  