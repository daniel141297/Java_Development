package com.java.fsd.abstraction;

public class Test   
{  
public static void main(String[] args)   
{  
Circle circle = new Circle();  
//invoking abstract method draw()  
circle.draw();  
}  
}  
