package com.java.fsd.inheritance;

class Parent {
	private int a;
	int b;

	public void m1() {
		System.out.println("This is method m1 of class Child_A");
	}
}
