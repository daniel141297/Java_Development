package com.java.fsd.inheritance;

//public class  

public class MainClass{
    public static void main(String args[]){
    	Parent childa = new Parent();
    	Child childb = new  Child();
    	childb.m2();
     //x.m1();
     //y.m1();
    //x = y;// parent pointing to object of child
    //x.m1() ;
    //y.a=10;
  }

}

