package com.java.fsd.overriding;

public class Child {
	void run() {
		System.out.println("Vehicle is running");
	}
}
