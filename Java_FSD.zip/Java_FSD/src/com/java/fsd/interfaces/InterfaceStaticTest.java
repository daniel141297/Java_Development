package com.java.fsd.interfaces;

public class InterfaceStaticTest {

	public static void main(String args[]){  
		Drawable d=new Rectangle();  
		d.draw();  
		System.out.println(Drawable.cube(3));  
		}

}
