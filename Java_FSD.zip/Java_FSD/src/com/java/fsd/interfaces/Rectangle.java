package com.java.fsd.interfaces;

class Rectangle implements Drawable{  
public void draw(){System.out.println("drawing rectangle");}  
}  