package com.java.fsd.constructor;

class StudentConstructorMain{  
    int id;  
    String name;  
    int age;  
    //creating two arg constructor  
    StudentConstructorMain(int i,String n){  
    id = i;  
    name = n;  
    }  
    //creating three arg constructor  
    StudentConstructorMain(int i,String n,int a){  
    id = i;  
    name = n;  
    age=a;  
    }  
    void display(){System.out.println(id+" "+name+" "+age);}  
   
    public static void main(String args[]){  
    StudentConstructorMain s1 = new StudentConstructorMain(111,"Karan");  
    StudentConstructorMain s2 = new StudentConstructorMain(222,"Aryan",25);  
    s1.display();  
    s2.display();  
   }  
}  
		
