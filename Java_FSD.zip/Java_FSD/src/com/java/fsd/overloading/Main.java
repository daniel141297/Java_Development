package com.java.fsd.overloading;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(Child.add(11, 11));
		System.out.println(Child.add(11, 11, 11));
		
		
	}

}
