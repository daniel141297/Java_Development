package com.java.fsd.arrayList;

//1. Write a Java program to create a new array list, add some colors (string) and print out the collection.

import java.util.*;

public class Main {
	public static void main(String[] args) {
		List<String> list_Strings = new ArrayList<String>();
		
		list_Strings.add("Red");
		list_Strings.add("Green");
		list_Strings.add("Orange");
		list_Strings.add("White");
		list_Strings.add("Black");
		
		System.out.println(list_Strings);
	}
}