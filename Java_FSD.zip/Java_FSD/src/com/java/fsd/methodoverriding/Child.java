package com.java.fsd.methodoverriding;

public class Child {

	void run() {
		System.out.println("Vehicle is running");
	}

}
