package com.java.fsd.methodoverriding;

public class Main extends Child{
	void run() {
		System.out.println("Bike is running safely");
	}

	public static void main(String args[]) {
		Main obj = new Main();// creating object
		obj.run();// calling method
	}
}
