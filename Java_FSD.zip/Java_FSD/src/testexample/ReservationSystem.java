package testexample;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ReservationSystem {

    static Map<String, Integer> map = new HashMap<>(); 

    public static void main(String[] args) {

        //put your customers name and seat number
        map.put("Jayant", 80); 
        map.put("Abhishek", 90); 
        map.put("Anushka", 80); 
        map.put("Amit", 75); 
        map.put("Danish", 40); 
        // use this method to sort based on keys
        //sortbykey();

        List<String> list=new ArrayList<String>();
        list.addAll(map.keySet());

        String temp;
        boolean sorted = false;
        while (!sorted) {
            sorted = true;
            for (int i = 0; i < list.size()-1; i++) {
                if (list.get(i).compareTo(list.get(i + 1)) > 0) {
                    temp = list.get(i);
                    list.set(i, list.get(i + 1));
                    list.set(i + 1, temp);
                    sorted = false;
                }
            }
        }

        System.out.println(list);


    }

}