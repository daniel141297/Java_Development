package testexample;

public class Test {

	 public static void main(String[] args) {
		 System.out.println("Output is :"+(9+6));
	 }
}
